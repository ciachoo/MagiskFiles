# Volume Steps Increase
This magisk module doubles the number of steps in volume adjustment for both media and in-call volume. [More details in support thread](=https://forum.xda-developers.com/showthread.php?t=3554996).

## Change Log
11.0.0
    - Magisk v11-compatible, use of template v2.

10.0.0
    - Initial release
