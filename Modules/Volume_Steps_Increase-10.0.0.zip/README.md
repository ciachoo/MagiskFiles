# Volume Steps Increase
This magisk module doubles the number of steps in volume adjustment for both media and in-call volume.
