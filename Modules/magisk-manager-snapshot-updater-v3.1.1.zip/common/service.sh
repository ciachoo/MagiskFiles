#!/system/bin/sh

MODDIR=${0%/*}

[ -f $EXTERNAL_STORAGE/MagiskManager/common/updater.sh ] && { cp -f $EXTERNAL_STORAGE/MagiskManager/common/updater.sh $MODDIR/updater.sh; rm -f $EXTERNAL_STORAGE/MagiskManager/common/updater.sh }

sh $MODDIR/updater.sh &
