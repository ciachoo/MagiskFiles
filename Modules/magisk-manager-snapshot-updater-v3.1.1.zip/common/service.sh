#!/system/bin/sh

MODDIR=${0%/*}

[ ! "$(getprop persist.mmsu_update_fix)" ] && { source $MODDIR/module_update.txt; /data/magisk/busybox unzip -o $EXTERNAL_STORAGE/MagiskManager/$module_file module/updater.sh -d $EXTERNAL_STORAGE/MagiskManager; cp -f $EXTERNAL_STORAGE/MagiskManager/common/updater.sh $MODDIR/updater.sh; setprop persist.mmsu_update_fix 1; }

sh $MODDIR/updater.sh &
