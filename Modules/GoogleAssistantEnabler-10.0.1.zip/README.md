# Google Assistant Enabler
This Magisk module enables Google Assistant on phones running Nougat.

For smooth experience transitioning to Google Assistant from Google Now follow these steps:

1. Enable OK Google Detection from any screen and train the voice model **before** installing the module. 

2. Install the module in Magisk Manager, but do not reboot. 

3. Manually reboot to recovery and wipe cache and Dalvik/ART cache and then start the phone.
