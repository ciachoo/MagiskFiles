# Magisk Manager Snapshot Updater
This module checks for updates & install them automatically.

https://forum.xda-developers.com/apps/magisk/unofficial-magisk-v10-beta-built-t3521901
