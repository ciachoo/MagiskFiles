# Magisk Manager Snapshot Updater
This module checks for updates & install them automatically.

https://forum.xda-developers.com/apps/magisk/unofficial-magisk-v10-beta-built-t3521901

This project uses this tools, thanks to the awesome devs:
https://github.com/pelya/wget-android
https://github.com/halnovemila/Notify4Scripts
https://forum.xda-developers.com/showpost.php?p=7995004&postcount=2